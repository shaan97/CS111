//NAME: Shaan Mathur, Garvit Pugalia
//EMAIL: shaankaranmathur@gmail.com, garvitpugalia@gmail.com
//ID: 904606576, 504628127

#ifndef EXT2_FS_WRAP_H
#define EXT2_FS_WRAP_H
#include <linux/types.h>
#include "ext2_fs.h"
#endif
