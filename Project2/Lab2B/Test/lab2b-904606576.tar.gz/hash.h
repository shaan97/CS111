/* NAME: SHAAN MATHUR
   EMAIL: SHAANKARANMATHUR@GMAIL.COM
   UID: 904606576
*/

// hash function for C-strings
long long hash(unsigned char *str);
